"""Core API v1."""

from . import tenant_pb2, tenant_pb2_grpc

__all__ = [
    "tenant_pb2",
    "tenant_pb2_grpc",
]
