"""IDP API v1."""

# Proto modules will be imported here when they exist
__all__ = []
